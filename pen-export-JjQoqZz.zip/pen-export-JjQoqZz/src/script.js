document.addEventListener('DOMContentLoaded', (event) => {
    alert('¡Bienvenido a la página infantil más divertida!');
});
